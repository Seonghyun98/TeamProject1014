package com.javaP.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.javaP.model.reserve.ReserveDao;
import com.javaP.model.reserve.ReserveDto;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class ReserveController {
	@Autowired
	private ReserveDao reserveDao;
	
	@Autowired
	private ReserveDto reserveDto;
	
	
	@RequestMapping("/GetAllReserve.do")
	@ResponseBody
	public Map<String, Object> getReserveList(){
		Map<String, Object> hashMap = new HashMap<String, Object>();
		List<ReserveDto> reserveList = reserveDao.getAllReserve();
		hashMap.put("reserveList", reserveList);
		return hashMap;
	}
}
