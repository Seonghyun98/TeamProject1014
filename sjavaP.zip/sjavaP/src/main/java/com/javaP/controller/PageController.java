package com.javaP.controller;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.javaP.model.qna.QnaDao;
import com.javaP.model.qna.QnaDto;
import com.javaP.model.qna.ReplyQnaDao;
import com.javaP.model.qna.ReplyQnaDto;
import com.javaP.utils.ScriptWriterUtil;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class PageController {
	
	@Autowired
	QnaDao qnaDao;
	
	@Autowired
	QnaDto qnaDto;
	
	@Autowired
	QnaDto prevQnaDto;
	
	@Autowired
	QnaDto nextQnaDto;
	
	@Autowired
	QnaDto currentNum;
	
	@Autowired
	ReplyQnaDao replyQnaDao;
	
	@Autowired
	ReplyQnaDto replyQnaDto;
	
	@RequestMapping("/Main.do") //메인페이지
	public String Main() {
		
		return "main/main";
	}
	
	@RequestMapping("/RoomForm.do") //공간페이지
	public String RoomForm() {
		
		return "room/room";
	}
	
	@RequestMapping("/Room2Form.do") //공간페이지
	public String Room2Form() {
		
		return "room/room2";
	}
	
	@RequestMapping("/Room3Form.do") //공간페이지
	public String Room3Form() {
		
		return "room/room3";
	}
	
	@RequestMapping("/Room4Form.do") //공간페이지
	public String Room4Form() {
		
		return "room/room4";
	}
	
	@RequestMapping("/PotoForm.do") //기록페이지(포토)
	public String PotoForm() {
		
		return "poto/poto";
	}
	
	@RequestMapping("/ServiceForm.do") //서비스페이지
	public String ServiceForm() {
		
		return "service/service";
	}
		
	@RequestMapping("/LocationForm.do") //위치페이지
	public String LocationForm() {
		
		return "location/location";
	}
	
	@RequestMapping("/TourForm.do") //여행페이지(관광명소)
	public String TourForm() {
		
		return "tour/tour";
	}
	
	
	
	
	
	
	
	@RequestMapping("/ReservationForm.do") //실시간예약페이지
	public String ReservationForm() {
		
		return "reservation/reservation";
	}
}
