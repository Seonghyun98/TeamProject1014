package com.javaP.model.gallery;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ReplyGalleryDao {
//	
//	@Autowired
//	private SqlSessionFactory sqlSessionFactory;
//	
//	public int insertReply(ReplyGalleryDto replyGalleryDto) {
//		int result = 0;
//		SqlSession sqlSession = sqlSessionFactory.openSession();
//		result = sqlSession.insert("insertReply", replyGalleryDto);
//		sqlSession.commit();
//		sqlSession.close();
//		
//		return result;
//	}
//	
//	public List<ReplyGalleryDto> getAllReply(int boardId) {
//		List<ReplyGalleryDto> replyList = null;
//		SqlSession sqlSession = sqlSessionFactory.openSession();
//		replyList = sqlSession.selectList("getAllReply", boardId);
//		sqlSession.close();
//		
//		return replyList;
//	}
//	
//	public int deleteReply(int no) {
//		int result = 0;
//		SqlSession sqlSession = sqlSessionFactory.openSession();
//		result = sqlSession.delete("deleteReply", no);		
//		sqlSession.commit();
//		
//		
//		sqlSession.close();
//		
//		return result;
//	}
}
