package com.javaP.model.reserve;

import org.springframework.stereotype.Repository;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Repository
public class ReserveDto {
	   private String reserve_date;
	   private int reserve_room;
	   private String name;
	   private String phone;
	   private String request;
	   private String arrive;
	   private String comeFrom;
	   private int persons;
	   private int vaccine;
}
