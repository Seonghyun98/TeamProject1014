package com.javaP.model.reserve;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class ReserveDao{
	@Autowired
	private SqlSessionFactory sqlSessionFactory;
	
	public List<ReserveDto> getAllReserve() {
		List<ReserveDto> reserveList = null;
		SqlSession sqlSession = sqlSessionFactory.openSession();
		reserveList = sqlSession.selectList("getAllReserve");
		sqlSession.close();
		return reserveList;
	}
	
	public int insertReserve(ReserveDto reserveDto) {
		int result = 0;
		
		SqlSession sqlSession = sqlSessionFactory.openSession();
		result = sqlSession.insert("insertReserve", reserveDto);
		
		sqlSession.commit();
		sqlSession.close();
		
		return result;
	}
}