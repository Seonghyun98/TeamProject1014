///////////////////////calendar////////////////////
let now;

function makeCalendar(pickedYear, pickedMonth, pickedDate) {
	let firstDay = new Date(pickedYear, pickedMonth, 1);
	const dayList = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];
	const monthList = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];
	const leapYear = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // 윤년
	const noneLeapYear = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // 평년

	let pageYear;

	const pickedNow = new Date();  // 실질적인 달력....

	firstDay = new Date(pickedYear, pickedMonth, 1);  // 넘어오는 날짜를 가지고 달력 구성
	const firstYear = firstDay.getFullYear();
	const month = monthList[pickedMonth];

	//윤년판단
	if (firstYear % 4 === 0) {
		if (firstYear % 100 === 0) {
			pageYear = noneLeapYear; //  윤년 아님
		} else {
			pageYear = leapYear; //  윤년 아님
		}
	} else {
		pageYear = noneLeapYear;
	}
	if (firstYear % 400 === 0) {
		pageYear = leapYear;
	}


	$(".contentsTitle").text(pickedYear + "년 " + (pickedMonth + 1) + "월");


	let count = 1;

	for (let i = 0; i < 42; i++) {
		// 일요일마다 한줄씩 추가
		if (i % 7 == 0) {
			$(".dates").append(`<tr class="weeks"></tr>`);
		}

		// 요일으로 시작일 판단,  오늘은 today 클래스를 붙여서 오늘임을 표시, 오늘 이전과 이후로 나누기.
		/////////////////////////////////////////////////////////////////////////////
		if (i < firstDay.getDay() || count > pageYear[pickedMonth]) {
			if (count > pageYear[pickedMonth] && firstDay.getDay() == 0) {
				break;
			}
			$(".weeks:last-child()").append(`<td class="blank"><span></span></td>`);
		} else {

			// 오늘 이전은 지났으므로, gone 클래스를 붙이고 데이터 안불러오기
			if (count < pickedDate) {
				$(".weeks:last-child()").append(`<td class="gone"><span>${count}</span></td>`);
			}
			else {
				$(".weeks:last-child()").append(`<td data-date ="${count}"><span>${count}</span></td>`);

				// 제일 최근 생성된 td에 각 방만큼의 링크 생성
				$(".calendarTable .dates .weeks:last-child td:last-child").append(`<ul id="rooms"></ul>`);
				
				for (var roomNum = 1; roomNum <= 4; roomNum++) {
					$(".weeks:last-child td:last-child #rooms:last-child").append(`<li class="room" data-roomNum="${roomNum}"><spam class="enable">가</spam><a href="#">자바룸 ${roomNum}</a></li>`);
				}

				// 오늘을 선택해서 표시         
				if (pickedNow.getFullYear() === now.getFullYear() &&
					pickedNow.getMonth() === now.getMonth() && count === pickedNow.getDate()) {
					$(`.weeks:nth-child(${i + 1})`).addClass("today");
				}
			}

			count++;
		}

		if (count > pageYear[pickedMonth] && i % 7 == 6) {
			break;
		}
	}
	
	let queryDate = pickedYear + "" + addZero(pickedMonth+1) + "" + addZero(pickedDate);
	const sendData = {
		reserve_date:queryDate
	}

	$.ajax({
		url: "GetAllReserve.do",
		data: sendData,
		method: "GET",
		success: function(resultData) {
			$.each(resultData.reserveList, function(i, item) {
				
				console.log(i,"==>",item)
				var date;
				var room;
				var name;
				var phone;
				
				
				
				date = item.date;
				room = item.room;
				name = item.name;
				phone = item.phone;
				

				$(`.weeks[date=${date}] .rooms[roomNum=${room}]`).html("")
					.append(`<li class="room" data-roomNum="${room}"><spam class="disable">완</spam>자바룸 ${room}</li>
						<p>${name} ${phone}</p>`);
			})
		},
		error: function(error) {
			console.log(queryDate, "/", sendData);
			console.log(error);
		}
	})
}

function addZero(month) {
	if (month < 10)
		return "0" + month;
	else
		return month;
}


window.addEventListener("load", function(event) {
	if (document.getElementsByClassName('calendar').length != 0) {
		now = new Date()
		makeCalendar(now.getFullYear(), now.getMonth(), now.getDate());
	}
});

